<template>
    <section>
        Filter
    </section>

    <section>
        <div class="controls">
            <button>Refresh</button>
            <router-link to="/register">Register as Coach</router-link>
        </div>
        <ul> 
            <li v-for="coach in filterCoaches" :key="coach.id">
                {{coach.firstName}}
            </li>
        </ul>
    </section>
</template>

<script>
export default{
    computed: {
        filterCoaches(){
            return this.$store.getters['coaches/coaches'];
        }
    }
}
</script>
